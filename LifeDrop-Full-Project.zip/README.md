# LifeDrop

A simple blood donor search website built with React and Vite.

## Run on your computer

1. Install [Node.js](https://nodejs.org/).
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.

## Publish with GitHub Pages

1. Create a new GitHub repository called `lifedrop`.
2. Upload all project files except `node_modules`.
3. In the repository, go to **Settings → Pages**.
4. Under **Build and deployment**, choose **GitHub Actions**.
5. Add the GitHub Pages workflow when prompted, or use a deployment service such as Vercel.

The compiled website is created with `npm run build` in the `dist` folder.
