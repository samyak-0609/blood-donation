import { useState } from 'react';
import { ArrowRight, Droplet, MapPin, Menu, Phone, ShieldCheck, X } from 'lucide-react';

const groups = ['Any blood group', 'A+', 'A−', 'B+', 'B−', 'AB+', 'AB−', 'O+', 'O−'];
const cities = ['Choose a city', 'Bengaluru', 'Chennai', 'Delhi', 'Hyderabad', 'Mumbai', 'Pune'];

export default function App() {
  const [bloodGroup, setBloodGroup] = useState(groups[0]);
  const [city, setCity] = useState(cities[0]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [message, setMessage] = useState('');

  function searchDonors(event) {
    event.preventDefault();
    if (city === cities[0]) {
      setMessage('Please choose a city to search for donors.');
      return;
    }
    setMessage(`Donor search for ${bloodGroup.toLowerCase()} blood in ${city} will be available when the database is connected.`);
  }

  function showMessage(text) {
    setMessage(text);
    window.setTimeout(() => setMessage(''), 3500);
  }

  return (
    <div className="page" id="home">
      <div className="notice"><Droplet size={15} fill="currentColor" /> A blood donation can help save a life.</div>
      <header className="header">
        <a className="logo" href="#home" aria-label="LifeDrop home"><span className="logo-icon"><Droplet size={21} fill="currentColor" /></span><span>LifeDrop<small>Blood donor network</small></span></a>
        <button className="menu-button" aria-label="Open menu" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'nav open' : 'nav'}>
          <a href="#find" onClick={() => setMenuOpen(false)}>Find donors</a>
          <a href="#steps" onClick={() => setMenuOpen(false)}>How it works</a>
          <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
        </nav>
        <a className="button button-small" href="#register">Register as a donor <ArrowRight size={15} /></a>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow">HELP SOMEONE NEAR YOU</span>
            <h1>Need blood?<br /><span>Find a donor.</span></h1>
            <p>Search for blood donors in your city. If you can donate, register to help someone who needs you.</p>
            <div className="hero-actions"><a className="button" href="#find">Find donors <ArrowRight size={16} /></a><a className="simple-link" href="#register">I want to donate</a></div>
            <div className="privacy-note"><ShieldCheck size={17} /> Your contact details are kept private.</div>
          </div>
          <div className="hero-picture" aria-hidden="true"><div className="circle circle-back" /><div className="drop-card"><Droplet size={94} fill="currentColor" strokeWidth={1.2} /><span>Give blood.<br />Help someone.</span></div><div className="picture-caption"><span className="caption-dot" /> Local donors. Real help.</div></div>
        </section>

        <section className="search-section" id="find">
          <div className="section-heading"><span className="eyebrow">FIND A DONOR</span><h2>Search by blood group and city</h2><p>Choose what you need, then search for nearby donors.</p></div>
          <form className="search-form" onSubmit={searchDonors}>
            <label>Blood group<select value={bloodGroup} onChange={e => setBloodGroup(e.target.value)}>{groups.map(group => <option key={group}>{group}</option>)}</select></label>
            <label>City<select value={city} onChange={e => setCity(e.target.value)}>{cities.map(item => <option key={item}>{item}</option>)}</select></label>
            <button className="button search-button" type="submit"><MapPin size={16} /> Search donors</button>
          </form>
          {message && <p className="form-message" role="status">{message}</p>}
          <p className="search-help">For urgent help, please contact a nearby hospital or blood bank.</p>
        </section>

        <section className="steps-section" id="steps">
          <div className="section-heading"><span className="eyebrow">HOW IT WORKS</span><h2>Three simple steps</h2></div>
          <div className="steps-grid"><article><span className="step-number">1</span><div><h3>Search</h3><p>Choose a blood group and city to look for donors.</p></div></article><article><span className="step-number">2</span><div><h3>Contact a donor</h3><p>Ask a willing donor to connect with you.</p></div></article><article><span className="step-number">3</span><div><h3>Donate safely</h3><p>Arrange donation through a hospital or blood bank.</p></div></article></div>
        </section>

        <section className="register-section" id="register"><div><span className="eyebrow">CAN YOU HELP?</span><h2>Become a blood donor</h2><p>Register your details so people in your area can find a willing donor.</p></div><button className="button button-white" onClick={() => showMessage('Donor registration will be added in the next step.')}>Register as a donor <ArrowRight size={16} /></button></section>
        <section className="about-section" id="about"><div className="about-icon"><Phone size={18} /></div><p><strong>LifeDrop helps people connect.</strong> Blood group compatibility and donation eligibility must be confirmed by medical professionals.</p></section>
      </main>

      <footer><a className="logo footer-logo" href="#home"><span className="logo-icon"><Droplet size={18} fill="currentColor" /></span><span>LifeDrop<small>Blood donor network</small></span></a><span>Every drop counts.</span></footer>
      {message && <div className="toast" role="status">{message}</div>}
    </div>
  );
}
